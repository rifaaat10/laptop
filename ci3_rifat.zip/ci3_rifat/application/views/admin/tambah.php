  <main class="main">
    
    <div class="container">

    <h1>halaman tambah laptop</h1>
    <br>

    <form action="<?php echo site_url('admin/dashboard_admin/get_insert'); ?>" method="post" enctype="multipart/form-data">
  
    <p>nama: <input type="text" name="nama"></p>
    <p>seri: <input type="text" name="seri"></p>
    <p>stok barang: <input type="number" name="stok_barang"></p>
    <p>harga: <input type="number" name="harga"></p>
    <p>gambar: <input type="file" name="foto" accept="image/"></p>

    <button type="submit" class="btn btn-primary">Tambah</button>

    </form>

    </div>

</main>
  