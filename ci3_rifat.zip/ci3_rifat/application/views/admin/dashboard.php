<main class="main">

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-8 content">
            <h2>Halaman Admin</h2>
            <p>selamat datang di halaman Admin</p>
            <br>
          </div>
        </div>

      </div>

    </section><!-- /About Section -->

    

<div class="container">
  <div class="row">

  <div class="card" style="width: 10rem;">
  <div class="card-body">
    <h5 class="card-title"><div class="btn btn-info"><i class="bi bi-people-fill"></i></div></h5>
    <b>populasi pembeli</b>
  </div>
</div>

<div class="card" style="width: 10rem;">
  <div class="card-body">
    <h5 class="card-title"><div class="btn btn-success"><i class="bi bi-hand-thumbs-up-fill"></div></i></h5>
    <b>banyak suka</b>
  </div>
</div>

<div class="card" style="width: 10rem;">
  <div class="card-body">
    <h5 class="card-title"><div class="btn btn-primary"><i class="bi bi-cart3"></i></div></h5>
    <b>jumlah laptop dibeli</b>
  </div>
</div>

<div class="card" style="width: 10rem;">
  <div class="card-body">
    <h5 class="card-title"><div class="btn btn-warning"><i class="bi bi-currency-dollar"></i></div></h5>
    <b>dapat penghsilan</b>
  </div>
</div>


  </div>
</div>


    

  </main>