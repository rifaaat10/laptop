<main class="main">
  <div class="container">
    
    <h1>halaman data laptop</h1>
    <br>
  <div class="btn btn-success">
    <a href="<?php echo site_url('admin/dashboard_admin/tambah') ?>">Tambah</a>
  </div>
  <br><br>
    
  </div>
  
  <table class="table">
    <thead>
    <tr>
      <th>no</th>
      <th>nama merek</th>
      <th>laptop seri</th>
      <th>stok barang</th>
      <th>harga</th>
      <th>gambar</th>
    </tr>
    </thead>
    
    <tbody>
      
      <?php 
      $no = 1;
      foreach($laptop as $brg): ?>
      
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $brg->nama ?></td>
      <td><?php echo $brg->seri ?></td>
      <td><?php echo $brg->stok_barang ?></td>
      <td><?php echo $brg->harga ?></td>
      <td><img src="<?php echo base_url($brg->foto) ?>" width="100"></td>
    </tr>
    
    <?php endforeach; ?>
    
    </tbody>
  </table>
  
</main>
      
