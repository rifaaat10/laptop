   <main class="main">
    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="<?php echo base_url() ?>/assets/portofolio/img/laptopfoto.jpeg" alt="" data-aos="fade-in" class="">

      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <h2>Toko Laptop Gaming</h2>
        <p>Laptop Merek: <span class="typed" data-typed-items="Lenovo, Apple, Acer, Asus, Samsung"></span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span></p>
      </div>

    </section><!-- /Hero Section -->
    
    <div class="container">
      <div class="row">
        
        <h3>halaman Laptop</h3>
        <br>
      
      <?php foreach($laptop as $brg): ?>

      <div class="card" style="width: 10rem;">
        <img src="<?php echo base_url($brg->foto) ?>" class="card-img-top" alt="...">
        <br>
        <div class="card-body">
        <h3><?php echo $brg->nama ?></h3>
        <small><?php echo $brg->seri ?></small>
        <br>
        <span class="badge text-bg-success"><?php echo $brg->harga ?></span>
        </div>
      </div>
      
      <?php endforeach; ?>
        
      </div>
    </div>

  </main>