<!DOCTYPE html>
<html>
<head>
  <title>Document</title>
</head>
<body>
  <h1>hello world</h1>
  <hr>
  <p>ini adalah default controller</p>
  <table border="1">
    <tr>
    <th>no</th>
    <th>nama</th>
    <th>email</th>
    <th>jurusan</th>
    </tr>
    
    <?php foreach($bio as $bdata): ?>
    <tr>
    <td><?php echo $bdata->id; ?></td>
    <td><?php echo $bdata->nama; ?></td>
    <td><?php echo $bdata->email; ?></td>
    <td><?php echo $bdata->jurusan; ?></td>
    </tr>
    
    <?php endforeach; ?>
    
  </table>
  
  <p>ini adalah database</p>
</body>
</html>