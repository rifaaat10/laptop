  <header id="header" class="header dark-background d-flex flex-column">
    <i class="header-toggle d-xl-none bi bi-list"></i>

    <div class="profile-img">
      <img src="<?php echo base_url(); ?>/assets/portofolio/img/my-profile-img.jpg" alt="" class="img-fluid rounded-circle">
    </div>

    <a href="index.html" class="logo d-flex align-items-center justify-content-center">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <!-- <img src="assets/img/logo.png" alt=""> -->
      <h1 class="sitename">Alex Smith</h1>
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="<?php echo site_url('dashboard/index') ?>" class="active"><i class="bi bi-house navicon"></i>Dashboard</a></li>
        <li><a href="#"><i class="bi bi-laptop navicon"></i>Laptop</a></li>
      </ul>
    </nav>

  </header>