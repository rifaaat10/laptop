  <footer id="footer" class="footer position-relative light-background">

    <div class="container">
      <div class="copyright text-center ">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">Tokoh Laptop</strong> <span>2025</span> | Rifat</p>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/typed.js/typed.umd.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/portofolio/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="<?php echo base_url(); ?>/assets/portofolio/js/main.js"></script>

</body>

</html>