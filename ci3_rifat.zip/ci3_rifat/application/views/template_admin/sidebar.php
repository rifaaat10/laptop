  <header id="header" class="header dark-background d-flex flex-column">
    <i class="header-toggle d-xl-none bi bi-list"></i>

    

    <a href="index.html" class="logo d-flex align-items-center justify-content-center">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <!-- <img src="assets/img/logo.png" alt=""> -->
      <h1 class="sitename">Admin</h1>
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="<?php echo site_url('admin/dashboard_admin/index') ?>" class="active"><i class="bi bi-house navicon"></i>Dashboard</a></li>
        <li><a href="<?php echo site_url('admin/dashboard_admin/data'); ?>"><i class="bi bi-database navicon"></i>Data Laptop</a></li>
      </ul>
    </nav>

  </header>