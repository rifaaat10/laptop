<?php

class Dashboard extends CI_Controller {
  
  public function __construct() {
    parent::__construct();
    $this->load->model('toko_model');
  }
  
  public function index() {
    $data['laptop'] = $this->toko_model->get();
    
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('dashboard', $data);
    $this->load->view('template/footer');
  }
  
}

?>