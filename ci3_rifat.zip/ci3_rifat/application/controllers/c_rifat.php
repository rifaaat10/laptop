<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_rifat extends CI_Controller {

	public function index()
	{
	  $this->load->model('bio_model');
	  $data['bio'] = $this->bio_model->get_bio();
	  
		$this->load->view('v_rifat', $data);
	}

}
