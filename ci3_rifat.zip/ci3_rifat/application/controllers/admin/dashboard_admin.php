<?php

class Dashboard_admin extends CI_Controller {
  
  public function __construct() {
    parent::__construct();
    $this->load->model('toko_model');
  }
  
  public function index() {
    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/dashboard');
    $this->load->view('template_admin/footer');
  }
  
  public function data() {
    $data['laptop'] = $this->toko_model->get();
    
    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/data', $data);
    $this->load->view('template_admin/footer');
  }
  
  public function tambah() {
    $this->load->view('template_admin/header');
    $this->load->view('template_admin/sidebar');
    $this->load->view('admin/tambah');
    $this->load->view('template_admin/footer');
  }
  
  public function get_insert() {
    $nama = $this->input->post('nama');
    $seri = $this->input->post('seri');
    $harga = $this->input->post('harga');
    $stok_barang = $this->input->post('stok_barang');
    $foto = $_FILES['foto']['tmp_name'];
    
    $path = 'assets/image/';
    $imagespath = $path. $username. 'p2.jpeg';
    $imagespath = $path. $username. 'p3.jpeg';
    $imagespath = $path. $username. 'p4.jpeg';
    $imagespath = $path. $username. 'produk1.jpeg';
    $imagespath = $path. $username. 'r.jpeg';
    $imagespath = $path. $username. 'p.jpeg';
    $imagespath = $path. $username. '24.jpeg';
    $imagespath = $path. $username. 'i.jpeg';
    move_uploaded_file($foto, $imagespath);
    
    $data = array(
      'nama' => $nama,
      'seri' => $seri,
      'harga' => $harga,
      'stok_barang' => $stok_barang,
      'foto' => $imagespath,
      );
      
      $this->toko_model->tambah($data, 'laptop');
      redirect('admin/Dashboard_admin/data');
  }
  
}

?>