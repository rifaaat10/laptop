<?php

class Toko_model extends CI_Controller {
  
  public function get() {
    return $this->db->get('laptop')->result();
  }
  
  public function tambah($data) {
    return $this->db->insert('laptop', $data);
  }
  
}

?>