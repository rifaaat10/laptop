<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bio_model extends CI_Model {

  public function get_bio() {
    return $this->db->get('bio')->result();
  }

}
